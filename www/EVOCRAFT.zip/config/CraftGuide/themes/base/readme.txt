Note: Do not alter any of the files in this directory, they are overwritten when CraftGuide loads.

If you want to customize or completely replace this, create a new theme and change currentTheme.txt so that the new theme loads instead of this one.

Look at dark/theme.xml or texpack_support/theme.xml for how to inherit from this theme, or copy it entirely, and change the id in the copy's theme.xml